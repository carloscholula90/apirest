<?php

use App\Models\Student;
use GraphQL\Type\Definition\Type;

$studentMutations = [
    'addStudent' => [
        'type' => $studentType,
        'args' => [
            'first_name' => Type::nonNull(Type::string()),
            'last_name' => Type::nonNull(Type::string()),
            'email' => Type::nonNull(Type::string()),
        ],
        'resolve' => function($root, $args) {
            $student = new Student([
                'first_name' => $args['first_name'],
                'last_name' => $args['last_name'],
                'email' => $args['email'],
            ]);
            $student->save();
            return $student->toArray();
        }
    ],
    'modifyStudent' => [
        'type' => $studentType,
        'args' => [
            'id' => Type::nonNull(Type::int()),
            'first_name' => Type::string(),
            'last_name' => Type::string(),
            'email' => Type::string()
        ],
        'resolve' => function($root, $args) {
            $student = Student::find($args['id']);
            $student->first_name = isset($args['first_name']) ? $args['first_name'] : $student->first_name;
            $student->last_name = isset($args['last_name']) ? $args['last_name'] : $student->last_name;
            $student->email = isset($args['email']) ? $args['email'] : $student->email;            
            $student->save();

            return $student->toArray();
        }
    ],
    'deleteStudent' => [
        'type' => $studentType,
        'args' => [
            'id' => Type::nonNull(Type::int())
        ],
        'resolve' => function($root, $args) {
            $student = Student::find($args['id']);
            $student->delete();
            return $student->toArray();
        }
    ],
];