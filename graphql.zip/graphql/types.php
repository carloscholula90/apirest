<?php

use App\Models\Address;
use App\Models\Student;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\Type;

$studentType = new ObjectType([
    'name' => 'Student',
    'description' => 'Este es el tipo de dato Estudiante',
    'fields' => function() use(&$addressType) {
        return [
            'id' => Type::int(),
            'first_name' => Type::string(),
            'last_name' => Type::string(),
            'email' => Type::string(),
            'addresses' => [
                "type" => Type::listOf($addressType),
                "resolve" => function ($root, $args) {
                    $studentId = $root['id'];
                    $student = Student::where('id', $studentId)->with(['addresses'])->first();
                    return $student->addresses->toArray();
                }
            ]
        ];
    }    
]);

$addressType = new ObjectType([
    'name' => 'Address',
    'description' => 'Este es el tipo de dato Direccion',
    'fields' => [
        'id' => Type::int(),
        'student_id' => Type::int(),
        'name' => Type::string(),
        'description' => Type::string(),
        'student' => [
            "type" => $studentType,
            "resolve" => function ($root, $args) {
                $addressId = $root['id'];
                $address = Address::where('id', $addressId)->with(['student'])->first();
                return $address->student->toArray();
            }
        ]       
    ]
]);