<?php

use App\Models\Address;
use App\Models\Student;
use GraphQL\Type\Definition\ObjectType;
use GraphQL\Type\Definition\Type;

$rootQuery = new ObjectType([
    'name' => 'Query',
    'fields' => [
        'student' => [
            'type' => $studentType,
            'args' => [
                'id' => Type::nonNull(Type::int())
            ],
            'resolve' => function($root, $args) {
                $student = Student::find($args["id"])->toArray();
                return $student;
            }
        ],
        'students' => [
            'type' => Type::listOf($studentType),            
            'resolve' => function($root, $args) {
                $students = Student::get()->toArray();
                return $students;
            }
        ],
        'address' => [
            'type' => $addressType,
            'args' => [
                'id' => Type::nonNull(Type::int())
            ],
            'resolve' => function($root, $args) {
                $address = Address::find($args["id"])->toArray();
                return $address;
            }
        ]
    ]
]);