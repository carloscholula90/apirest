<?php

use GraphQL\Type\Definition\ObjectType;

require('mutations/studentMutations.php');
require('mutations/addressMutations.php');

$mutations = array();
$mutations += $studentMutations;
$mutations += $addressMutations;

$rootMutation = new ObjectType([
    'name' => 'Mutation',
    'fields' => $mutations
]);